import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MyServicesService } from '../HttpServices/my-services.service';

@Component({
  selector: 'app-forget-password-comp',
  templateUrl: './forget-password-comp.component.html',
  styleUrls: ['./forget-password-comp.component.css']
})
export class ForgetPasswordCompComponent implements OnInit {

  typeUser: string;
  userGmailId: string;
  imageUrl: string;
  checkGmail: boolean;
  otp: string;

  success: boolean;

  password: string;
  confirmpassword: string;

  steps: number;
  renteredOTP: string;
  checkotp: boolean;
  loader: boolean;
  comparspssaword: boolean;

  constructor(private routerActive: ActivatedRoute, private router: Router, private httpReq: MyServicesService) {
    this.checkGmail = false;
    this.steps = 0;
    this.loader = false;
    this.comparspssaword = false;
    console.log(this.steps);
   }

  ngOnInit(): void {
    this.routerActive.params.subscribe(params => {
      this.typeUser = params.typeUser;

      if (this.typeUser !== 'user' && this.typeUser !== 'admin')
      {
        this.router.navigate([''], { replaceUrl: true });
      }
      if (this.typeUser === 'user')
      {
        this.imageUrl = 'https://st2.depositphotos.com/7107694/10781/v/950/depositphotos_107818026-stock-illustration-patient-flat-vector-symbol.jpg';
      }
      else if (this.typeUser === 'admin')
      {
        this.imageUrl = 'https://www.iconsdb.com/icons/preview/red/administrator-xxl.png';
        }
     });
  }

  verfiyGmail()
  {
    this.loader = true;
    this.httpReq.getReq('http://localhost:8080/verfiyGmail/' + this.userGmailId + '/' + this.typeUser + '/').subscribe(
      response => {
        console.log(response);
        this.checkGmail = response !== true;
        if (!this.checkGmail) {

          this.sendOTPToMail();
        }
        else
        {
          this.loader = false;
         }
       });
  }

  sendOTPToMail()
  {
    this.otp = String(Math.floor(Math.random() * 1000000));
    this.httpReq.getReq('http://localhost:8080/sendgmail/' + this.typeUser + '/' + this.userGmailId + '/' + this.otp  + '/').subscribe(
      response => {
        console.log(response);
        this.steps = 1;
        this.loader = false;
       });
  }

  compareOTP()
  {
    if (this.renteredOTP === this.otp) {
      this.steps = 2;

    } else {
      this.comparspssaword = true;
     }

  }
  updatePassword()
  {
    this.loader = true;
    if (this.password === this.confirmpassword)
    {
      this.httpReq.getReq('http://localhost:8080/updatepassword/' + this.userGmailId + '/' + this.password + '/').subscribe(
        response => {
          this.steps = 3;
          console.log(response);
          this.loader = false;
         });
     }
  }


}
