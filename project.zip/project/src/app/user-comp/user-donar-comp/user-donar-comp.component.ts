import { Component, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-user-donar-comp',
  templateUrl: './user-donar-comp.component.html',
  styleUrls: ['./user-donar-comp.component.css']
})
export class UserDonarCompComponent implements OnInit {
  donerList: any = [];
  donersearchList: any = [];
  searchData: string;

  constructor(private httpReq: MyServicesService) { }

  ngOnInit(): void {
    this.getAllDonors();
  }
  refreash() {
    this.getAllDonors();
  }
  getAllDonors(): void {
    this.httpReq.getReq('http://localhost:8080/getAllDoners/').subscribe(
      response => {
        this.donerList = response;
        console.log(response);
        this.searchByFields('');
      });
  }

  searchByFields(data: string) {
    console.log(data);
    this.donersearchList = [];
    for (const donarIndex in this.donerList) {
      if (String(this.donerList[donarIndex].donarName).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].age).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].weight).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].phoneNumber).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].pressure).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].pHLevel).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (String(this.donerList[donarIndex].bloodgroup).includes(data)) {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
      else if (data === null || data === '') {
        this.donersearchList.push(this.donerList[donarIndex]);
      }
    }
    console.log(this.donersearchList);
  }


}
