import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserDonarCompComponent } from './user-donar-comp.component';

describe('UserDonarCompComponent', () => {
  let component: UserDonarCompComponent;
  let fixture: ComponentFixture<UserDonarCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserDonarCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserDonarCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
