import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserprofileCompComponent } from './userprofile-comp.component';

describe('UserprofileCompComponent', () => {
  let component: UserprofileCompComponent;
  let fixture: ComponentFixture<UserprofileCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserprofileCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserprofileCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
