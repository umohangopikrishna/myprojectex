import { Component, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-userprofile-comp',
  templateUrl: './userprofile-comp.component.html',
  styleUrls: ['./userprofile-comp.component.css']
})
export class UserprofileCompComponent implements OnInit {

  userData: any;
  loader: boolean;
  updateloader: boolean;
  constructor(private httpReq: MyServicesService)
  {
    this.loader = false;
    this.updateloader = false;
   }

  ngOnInit(): void {
    this.getUserData();
  }
  getUserData()
  {
    this.loader = true;
    this.httpReq.getReq('http://localhost:8080/getUserDataByUserId/' + sessionStorage.getItem('userId') + '/').subscribe(
      response => {
        this.userData = response;
        console.log(this.userData);
        this.loader = false;
             },
      err => {
        this.loader = false;
      });
  }
  updateData()
  {
    this.updateloader = true;
    console.log(this.userData);
    this.httpReq.postReq('http://localhost:8080/updateprofile/', this.userData).subscribe(
      response =>
      {
        console.log(response);
        this.updateloader = false;
      });
   }

}
