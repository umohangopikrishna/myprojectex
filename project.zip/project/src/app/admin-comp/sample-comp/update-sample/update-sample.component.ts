import { Component, Input, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-update-sample',
  templateUrl: './update-sample.component.html',
  styleUrls: ['./update-sample.component.css']
})
export class UpdateSampleComponent implements OnInit {
  @Input() sampleData: any;

  location: string;
  packs: number;
  packetdate: string;
  phoneNumber: string;
  address: string;
  phlevel: number;
  pressure: number;
  bloodgroup: string;

  formData: any = {
    id: 0,
    location: '',
    packs: 0,
    phoneNumber: '',
    address: '',
    phlevel: 0,
    pressure: 0,
    bloodgroup: '',

  };
  loader: boolean;
  constructor(private httpReq: MyServicesService)
  {
    this.loader = false;
   }

  ngOnInit(): void {

    this.packs = this.sampleData.packs;
    this.packetdate = this.sampleData.packetdate;
    this.phoneNumber = this.sampleData.phoneNumber;
    this.address = this.sampleData.address;
    this.phlevel = this.sampleData.phlevel;
    this.pressure = this.sampleData.pressure;
    this.bloodgroup = this.sampleData.bloodgroup;
    this.location = this.sampleData.location;
  }

  addressUpdate()
  {
    if (navigator.geolocation) {

      navigator.geolocation.getCurrentPosition((position) => {
        console.log(position.coords.latitude + ',' + position.coords.longitude);
        this.location = String(position.coords.latitude + ',' + position.coords.longitude);
      });
                             }
  }
  updateSample()
  {
    this.loader = true;
    this.formData.packs =  this.packs;
    this.formData.phoneNumber = this.phoneNumber;
    this.formData.address = this.address;
    this.formData.phlevel = this.phlevel;
    this.formData.pressure = this.pressure;
    this.formData.bloodgroup = this.bloodgroup;
    this.formData.location = this.location;
    this.formData.id = this.sampleData.id;
    console.log(this.formData);
    this.httpReq.putReq('http://localhost:8080/updateSampleData/', this.formData).subscribe(
      response => {
        console.log(response);
        this.loader = false;
      },
      err => {
        this.loader = false;
      });

  }


}
