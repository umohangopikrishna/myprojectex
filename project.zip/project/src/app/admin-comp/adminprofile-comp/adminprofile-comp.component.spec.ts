import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminprofileCompComponent } from './adminprofile-comp.component';

describe('AdminprofileCompComponent', () => {
  let component: AdminprofileCompComponent;
  let fixture: ComponentFixture<AdminprofileCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminprofileCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminprofileCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
