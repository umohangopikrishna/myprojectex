import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-donar-box',
  templateUrl: './donar-box.component.html',
  styleUrls: ['./donar-box.component.css']
})
export class DonarBoxComponent implements OnInit {
  @Input() donerData: any;
  viewMode: boolean;
  constructor() { }

  ngOnInit(): void {
    this.viewMode = false;
  }
  showDetails()
  {
    this.viewMode = true;
  }

}
