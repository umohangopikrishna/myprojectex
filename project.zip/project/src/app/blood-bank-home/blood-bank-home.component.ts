import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blood-bank-home',
  templateUrl: './blood-bank-home.component.html',
  styleUrls: ['./blood-bank-home.component.css']
})
export class BloodBankHomeComponent implements OnInit {



  constructor() {

  }
  ngOnInit(): void {
  }



}
